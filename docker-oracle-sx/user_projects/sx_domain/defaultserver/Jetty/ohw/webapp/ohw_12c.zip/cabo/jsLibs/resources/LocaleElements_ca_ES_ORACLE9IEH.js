var LocaleSymbols_ca_ES = new LocaleSymbols({
DateTimeElements:["2", "4"], 
MonthAbbreviations:["muharram", "safar", "rabi\x27 awwal", "rabi\x27 thani", "jamada el oula", "jamada el thani", "rajab", "sha\x27ban", "ramadan", "shawwal", "thoul ki\x27dah", "thoul hijjah"], 
DayNames:["diumenge", "dilluns", "dimarts", "dimecres", "dijous", "divendres", "dissabte"], 
NumberElements:[",", ".", ";", "%", "0", "#", "-", "E", "\u2030", "\u221e", "\ufffd"], 
DateTimePatterns:["HH:mm:ss z", "HH:mm:ss z", "HH:mm:ss", "HH:mm", "EEEE, d\x27 / \x27MMMM\x27 / \x27yyyy", "d\x27 / \x27MMMM\x27 / \x27yyyy", "dd/MM/yyyy", "dd/MM/yy", "{1} {0}"], 
Eras:["BH", ""], 
AmPmMarkers:["AM", "PM"], 
DayAbbreviations:["dg", "dl", "dm", "dc", "dj", "dv", "ds"], 
MonthNames:["muharram", "safar", "rabi\x27 awwal", "rabi\x27 thani", "jamada el oula", "jamada el thaniah", "rajab", "sha\x27ban", "ramadan", "shawwal", "thoul ki\x27dah", "thoul hijjah"]
});
